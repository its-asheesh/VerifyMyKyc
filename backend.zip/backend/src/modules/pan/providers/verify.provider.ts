// Placeholder for future PAN verification provider
